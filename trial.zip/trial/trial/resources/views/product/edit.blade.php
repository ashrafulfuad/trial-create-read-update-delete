
@extends('layouts.app')

@section('content')

<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h3>Product Update of {{ $product_edit->product_name }}</h3>
      <form action="{{ url('product/edit/insert') }}" method="post">
        {{ csrf_field() }}
        <div class="form-group">
          <label >Product Name</label>
          <input type="hidden" name="product_id" value="{{ $product_edit->id }}">
          <input type="text" name="product_name" class="form-control" value="{{ $product_edit->product_name }}">
        </div>
        <div class="form-group">
          <label >Product Price</label>
          <input type="" name="product_price" class="form-control" value="{{ $product_edit->product_price }}">
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
      </form>
      </div>
    </div>
  </div>
</div>
@endsection
