<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-left">
        <div class="col-md-4">
          <h3>Add Product</h3>
          
          <?php if(session('status')): ?>
            <div class="alert alert-success">
              <?php echo e(session('status')); ?>

            </div>
          <?php endif; ?>

          
          <?php if($errors->all()): ?>
            <div class="alert alert-danger">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          <?php endif; ?>

          <form action="<?php echo e(url('product/insert')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
              <label >Product Name</label>
              <input type="text" name="product_name" class="form-control" value="<?php echo e(old('product_name')); ?>">
            </div>
            <div class="form-group">
              <label >Product Price</label>
              <input type="" name="product_price" class="form-control" value="<?php echo e(old('product_price')); ?>">
            </div>
            <button type="submit" class="btn btn-primary">Add</button>
          </form>
        </div>
        <div class="col-md-8">
          <div class="row">
            <div class="col-md-12">
              <h3>Product List</h3>
              
              <?php if(session('delete_status')): ?>
                <div class="alert alert-danger">
                  <?php echo e(session('delete_status')); ?>

                </div>
              <?php endif; ?>

              <table class="table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Product Name</th>
                    <th>Product Price</th>
                    <th>Created At</th>
                    <th>Option</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($product->id); ?></td>
                      <td><?php echo e(title_case($product->product_name)); ?></td>
                      <td><?php echo e($product->product_price); ?>Tk</td>
                      <td><?php echo e($product->created_at->format('d-M-y h:i:s a')); ?></td>
                      <td>
                        <a type="button" class="btn btn-sm btn-danger" href="<?php echo e(url('product/delete')); ?>/<?php echo e($product->id); ?>">Del</a>
                        <a type="button" class="btn btn-sm btn-info" href="<?php echo e(url('product/edit')); ?>/<?php echo e($product->id); ?>">edit</a>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              <?php echo e($products->links()); ?>

            </div>
            <div class="col-md-12">
              <h3>Deleted Product List</h3>
              <table class="table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Product Name</th>
                    <th>Product Price</th>
                    <th>Option</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $deleted_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deleted_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($deleted_product->id); ?></td>
                      <td><?php echo e(title_case($deleted_product->product_name)); ?></td>
                      <td><?php echo e($deleted_product->product_price); ?>Tk</td>
                      <td>
                        <a type="button" class="btn btn-sm btn-info" href="<?php echo e(url('product/restore')); ?>/<?php echo e($deleted_product->id); ?>">Restore</a>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              <?php echo e($products->links()); ?>

            </div>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>